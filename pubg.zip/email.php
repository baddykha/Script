<?php
$emailku = 'baddykha410@gmail.com'; // GANTI EMAIL KAMU DISINI
?>