<div class="menu-change">
Do you want to change to another reward?
<button type="button" onclick="changReward('pages/material');">Change Reward</button>
</div>
<div class="scroll">
<center>
<div class="balance">
<img src="https://i.ibb.co/M6KSf3N/paint.png">
<div class="balance-nom">20</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/M6KSf3N/paint.png">Collect</button>
</div>
<div class="balance">
<img src="https://i.ibb.co/M6KSf3N/paint.png">
<div class="balance-nom">30</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/M6KSf3N/paint.png">Collect</button>
</div>
<div class="balance">
<img src="https://i.ibb.co/M6KSf3N/paint.png">
<div class="balance-nom">40</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/M6KSf3N/paint.png">Collect</button>
</div>
<div class="balance">
<img src="https://i.ibb.co/M6KSf3N/paint.png">
<div class="balance-nom">50</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/M6KSf3N/paint.png">Collect</button>
</div>
<div class="balance">
<img src="https://i.ibb.co/M6KSf3N/paint.png">
<div class="balance-nom">60</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/M6KSf3N/paint.png">Collect</button>
</div>
</center>
</div> <!--- scroll --->