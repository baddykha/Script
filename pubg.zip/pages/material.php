<div class="menu-change">
Do you want to change to another reward?
<button type="button" onclick="changReward('pages/weapon');">Change Reward</button>
</div>
<div class="scroll">
<center>
<div class="balance">
<img src="https://i.ibb.co/8szxyNW/material.png">
<div class="balance-nom">3</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/8szxyNW/material.png">Collect</button>
</div>
<div class="balance">
<img src="https://i.ibb.co/8szxyNW/material.png">
<div class="balance-nom">5</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/8szxyNW/material.png">Collect</button>
</div>
<div class="balance">
<img src="https://i.ibb.co/8szxyNW/material.png">
<div class="balance-nom">7</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/8szxyNW/material.png">Collect</button>
</div>
<div class="balance">
<img src="https://i.ibb.co/8szxyNW/material.png">
<div class="balance-nom">9</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/8szxyNW/material.png">Collect</button>
</div>
<div class="balance">
<img src="https://i.ibb.co/8szxyNW/material.png">
<div class="balance-nom">12</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/8szxyNW/material.png">Collect</button>
</div>
</center>
</div> <!--- scroll --->