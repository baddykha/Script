<div class="menu-change">
Do you want to change to another reward?
<button type="button" onclick="changReward('pages/paint');">Change Reward</button>
</div>
<div class="scroll">
<center>
<div class="balance">
<img src="https://i.ibb.co/6R7W9xR/uc.png">
<div class="balance-nom">250 + 13</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/6R7W9xR/uc.png">Collect</button>
</div>
<div class="balance">
<img src="https://i.ibb.co/6R7W9xR/uc.png">
<div class="balance-nom">500 + 30</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/6R7W9xR/uc.png">Collect</button>
</div>
<div class="balance">
<img src="https://i.ibb.co/6R7W9xR/uc.png">
<div class="balance-nom">1250 + 125</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/6R7W9xR/uc.png">Collect</button>
</div>
<div class="balance">
<img src="https://i.ibb.co/6R7W9xR/uc.png">
<div class="balance-nom">2500 + 375</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/6R7W9xR/uc.png">Collect</button>
</div>
<div class="balance">
<img src="https://i.ibb.co/6R7W9xR/uc.png">
<div class="balance-nom">5000 + 1000</div>
<div class="balance-detail">Additional reward for Season 17</div>
<button onclick="open_reward_confirmation(this);" src="https://i.ibb.co/6R7W9xR/uc.png">Collect</button>
</div>
</center>
</div> <!--- scroll --->