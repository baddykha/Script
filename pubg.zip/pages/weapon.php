<div class="menu-change">
Do you want to change to another reward?
<button type="button" onclick="changReward('pages/uc');">Change Reward</button>
</div>
<div class="scroll">
<center>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/JK5QkCq/1.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/JK5QkCq/1.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/N1Kh4DJ/m249.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/N1Kh4DJ/m249.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/n0jsqH6/1.jpg">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/n0jsqH6/1.jpg">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/tC7gGKh/2.jpg">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/tC7gGKh/2.jpg">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/HdCPbym/3.jpg">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/HdCPbym/3.jpg">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/zHXhQmQ/8.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/zHXhQmQ/8.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/hcnPCFM/9.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/hcnPCFM/9.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/S78nnmC/1.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/S78nnmC/1.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/Lk3B2mw/2.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/Lk3B2mw/2.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/YpbSGGN/3.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/YpbSGGN/3.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/54C3TwS/1.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/54C3TwS/1.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/8rwnBbf/2.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/8rwnBbf/2.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/JyKsRV9/3.jpg">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/JyKsRV9/3.jpg">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/9NW5RBs/1.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/9NW5RBs/1.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/DrzYVS0/2.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/DrzYVS0/2.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/3cM96Bn/3.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/3cM96Bn/3.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/30shkpG/4.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/30shkpG/4.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/DYcd3r8/5.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/DYcd3r8/5.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/m5MfkNp/6.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/m5MfkNp/6.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/0hG72h9/7.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/0hG72h9/7.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/c232k1x/8.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/c232k1x/8.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/smrqkwd/9.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/smrqkwd/9.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/stysM7v/10.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/stysM7v/10.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/WgYyGnw/11.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/WgYyGnw/11.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/pdYW33J/12.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/pdYW33J/12.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/N9XVcKh/13.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/N9XVcKh/13.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/X8Y41sj/14.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/X8Y41sj/14.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/mhWQMvq/15.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/mhWQMvq/15.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/Rjh4zr4/16.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/Rjh4zr4/16.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/qB0F8jV/17.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/qB0F8jV/17.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/n8pTPFf/18.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/n8pTPFf/18.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/rkkQqXM/20.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/rkkQqXM/20.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/jTsg4BQ/21.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/jTsg4BQ/21.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/v332bhy/4.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/v332bhy/4.png">Collect</button>
</div>
</div>
<div class="item">
<img style="border-bottom: 0px;" src="https://i.ibb.co/9sw3NZK/5.png">
<div>
<button onmousedown="buka.play();" onclick="open_reward_confirmation(this);" src="https://i.ibb.co/9sw3NZK/5.png">Collect</button>
</div>
</div>
</center>
</div> <!--- scroll --->